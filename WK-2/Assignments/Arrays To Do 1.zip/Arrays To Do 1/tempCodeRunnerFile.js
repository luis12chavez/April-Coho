      // if (index === pos) {
        //     // arr[index] = temp
        //     console.log(arr[index])
        //     // arr[index] = arr[arr.length - 1]
        //     // arr[arr.length - 1] = temp
        // }